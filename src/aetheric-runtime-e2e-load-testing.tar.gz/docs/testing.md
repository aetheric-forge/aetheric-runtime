# End-to-end and load testing

The external-provider test suite validates Runtime contracts against deployed infrastructure. It is deliberately separate from deterministic unit tests because it creates real S3 objects, MongoDB documents, RabbitMQ exchanges, queues, and messages.

## Configuration

Set configuration through system environment variables. For local development, copy `.env.example` to an ignored `.env` file and load it with your preferred environment manager. The test programs do not read or print credentials themselves.

Use dedicated test infrastructure where possible. All archive keys are namespaced beneath a unique run ID and deleted after successful or failed assertions. RabbitMQ resources are durable because that is part of the provider's production behaviour; use a dedicated test domain or virtual host so they can be expired or removed operationally.

## Integration tests

Run the opt-in project directly:

```bash
dotnet test src/Tests/AethericForge.Runtime.IntegrationTests/AethericForge.Runtime.IntegrationTests.csproj
```

Each provider test performs a real write/publish operation. Archive tests then read, validate metadata and content, delete the artifact, and verify deletion. The RabbitMQ test subscribes before publishing and validates end-to-end delivery.

## Load runner

The load runner exercises the same public provider contracts as Runtime. Select one target at a time with `AF_LOAD_TARGET`: `mongodb`, `s3`, or `rabbitmq`.

```bash
AF_LOAD_TARGET=mongodb \
AF_LOAD_CONCURRENCY=16 \
AF_LOAD_DURATION_SECONDS=60 \
dotnet run --project src/Tools/AethericForge.Runtime.LoadTest/AethericForge.Runtime.LoadTest.csproj -c Release
```

It reports completed operations, errors, throughput, and p50/p95/p99 latency. It exits non-zero when `AF_LOAD_MAX_ERROR_RATE` or `AF_LOAD_MAX_P95_MS` is exceeded, making a modest test suitable for CI.

Archive operations are full write/read/verify/delete cycles. RabbitMQ operations measure confirmed client publication, not consumer delivery; the integration test separately verifies delivery semantics.

Start with low concurrency and increase in controlled stages. Do not run stress or soak profiles against shared production infrastructure without an explicit capacity-test window and monitoring.
